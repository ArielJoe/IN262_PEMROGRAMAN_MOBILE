package com.example.utsmobile2372015ariel.entity

data class Response(
    var status: String,
    var message: String,
    var data: List<AnimeManga>
)