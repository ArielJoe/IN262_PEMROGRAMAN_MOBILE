package com.example.utsmobile2372015ariel.entity

data class AnimeManga(
    var id: Number,
    var nama: String,
    var kategori: String,
    var rating: Float,
    var tahun_terbit: Number
)